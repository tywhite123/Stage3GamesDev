#include "GameSaver.h"



GameSaver::GameSaver(std::string gameSave, std::vector<GameObject*>& objects)
{
}


GameSaver::~GameSaver()
{
}
