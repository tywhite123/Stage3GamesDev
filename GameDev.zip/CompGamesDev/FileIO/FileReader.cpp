#include "FileReader.h"



FileReader::FileReader(std::string gameInfo, std::vector<GameObject*>& objects)
{
}


FileReader::~FileReader()
{
}
