#include "EventQueue.h"



EventQueue::EventQueue()
{
}


EventQueue::~EventQueue()
{
}
